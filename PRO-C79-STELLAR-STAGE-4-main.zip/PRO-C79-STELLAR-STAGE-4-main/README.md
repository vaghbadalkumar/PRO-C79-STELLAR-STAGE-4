# PRO-C79-STELLAR-STAGE-4
In This Project, You Will Create A Similar “Daily Pic” Screen For The Stellar App.
